# Design Tokens - Ally Modern App

## 🎨 Quick Reference

### Primary Color
```
#7C3AED - Vibrant Purple (Main)
#F0E6FF - Light Purple (Backgrounds)
#6D28D9 - Deep Purple (Hover)
#5B21B6 - Very Deep Purple (Active)
```

### Secondary Color
```
#0EA5E9 - Vibrant Cyan (Accent)
#E0F2FE - Light Cyan (Backgrounds)
#0284C7 - Deep Cyan (Active)
```

### Accent Color
```
#F59E0B - Vibrant Amber (Warnings)
#FEF3C7 - Light Amber (Backgrounds)
#D97706 - Deep Amber (Active)
```

### Mood Colors
```
Happy:     #FBBF24 (Gold)
Energetic: #EF4444 (Red)
Neutral:   #3B82F6 (Blue)
Calm:      #10B981 (Green)
Sad:       #A855F7 (Purple)
```

### Semantic Colors
```
Success: #10B981 (Green)
Warning: #F59E0B (Amber)
Error:   #EF4444 (Red)
Info:    #3B82F6 (Blue)
```

### Neutral Colors
```
White:     #FFFFFF
Off-white: #F9FAFB
Light:     #F3F4F6
Medium:    #E5E7EB
Dark:      #9CA3AF
Charcoal:  #374151
Black:     #111827
```

---

## 📏 Spacing

```
4px  - xs (tight spacing)
8px  - sm (small spacing)
12px - md (medium spacing)
16px - lg (standard spacing)
24px - xl (large spacing)
32px - xxl (extra large)
48px - xxxl (huge spacing)
```

---

## 🔘 Border Radius

```
4px   - xs (subtle)
8px   - sm (small)
12px  - md (cards)
16px  - lg (large cards)
20px  - xl (buttons)
24px  - xxl (modals)
9999px - full (circles)
```

---

## 🎯 Shadows

### Minimal Shadows
```
sm:  1px offset, 2px radius, 5% opacity
md:  2px offset, 4px radius, 8% opacity
lg:  4px offset, 8px radius, 10% opacity
xl:  8px offset, 12px radius, 12% opacity
```

### Glow Effects (Purple)
```
glow_sm: 6px radius, 30% opacity
glow_md: 10px radius, 40% opacity
glow_lg: 14px radius, 50% opacity
```

---

## 📝 Typography

### Headers
```
H1: 32px, 700 weight, -0.5 letter spacing
H2: 28px, 700 weight, -0.3 letter spacing
H3: 24px, 600 weight, -0.2 letter spacing
H4: 20px, 600 weight
```

### Body
```
Large:  16px, 400 weight, 24px line height
Medium: 14px, 400 weight, 20px line height
Small:  12px, 400 weight, 18px line height
```

### Labels
```
Large:  14px, 600 weight, 20px line height
Medium: 12px, 600 weight, 16px line height
Small:  11px, 600 weight, 14px line height
```

---

## 🌈 Gradients

### Primary
```
135deg: #F0E6FF → #E0F2FE
```

### Secondary
```
135deg: #E0F2FE → #FEF3C7
```

### Vibrant
```
135deg: #FBBF24 → #10B981
```

### Mood Gradients
```
Happy:     #FEF3C7 → #FBBF24
Energetic: #FEE2E2 → #EF4444
Neutral:   #DBEAFE → #3B82F6
Calm:      #D1FAE5 → #10B981
Sad:       #E9D5FF → #A855F7
```

---

## 🎬 Animation Timings

```
Fast:   150ms
Normal: 300ms
Slow:   500ms
Slower: 800ms
```

### Transitions
```
Smooth: cubic-bezier(0.4, 0, 0.2, 1)
Bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55)
Spring: cubic-bezier(0.34, 1.56, 0.64, 1)
```

---

## 🌙 Dark Mode

```
Background:      #0F172A
Surface:         #1E293B
Surface Light:   #334155
Text:            #F1F5F9
Text Secondary:  #94A3B8
```

---

## 💡 Usage Examples

### Button
```
Primary: #7C3AED background, white text, 20px radius
Secondary: #0EA5E9 background, white text, 20px radius
Outline: transparent, #7C3AED border, 20px radius
```

### Card
```
Elevated: white background, md shadow, 12-16px radius
Outlined: white background, light border, 12-16px radius
Filled: light background, no shadow, 12-16px radius
Glass: semi-transparent, blur effect, light border
```

### Chat Bubble
```
User:   #7C3AED background, white text, curved corners
Ally:   mood color background, white text, glow effect
```

### Input
```
Border: #E5E7EB
Focus: #7C3AED border with glow
```

---

## ✅ Design Checklist

- [ ] Use vibrant purple for primary actions
- [ ] Use cyan/amber for secondary actions
- [ ] Apply minimal shadows (not heavy)
- [ ] Use mood colors for emotional context
- [ ] Maintain high contrast for accessibility
- [ ] Use consistent spacing from scale
- [ ] Apply rounded corners (12-20px)
- [ ] Support dark mode
- [ ] Use smooth transitions (300ms)

---

**Last Updated**: November 11, 2025

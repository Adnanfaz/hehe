# Ally Modern UI Redesign

## 🎨 Design System Overview

A complete modern, minimalist redesign of Ally inspired by Replika, Calm, and Notion aesthetics. Features soft gradients, glassmorphic design, emotionally warm colors, and fluid interactions.

---

## 📋 Design Principles

### 1. **Emotional Warmth**
- Soft, pastel color palette
- Rounded corners and smooth transitions
- Gentle shadows and glow effects
- Responsive to user mood

### 2. **Minimalism**
- Clean, uncluttered layouts
- Generous whitespace
- Clear hierarchy
- Purposeful design elements

### 3. **Glassmorphism**
- Semi-transparent surfaces
- Subtle blur effects
- Layered depth
- Modern, contemporary feel

### 4. **Accessibility**
- High contrast text
- Large touch targets (44x44 minimum)
- Clear visual feedback
- Intuitive navigation

---

## 🎯 Navigation Redesign

### From 5+ Tabs → 3 Core Tabs

**New Navigation Structure:**
```
┌─────────────────────────────┐
│         Chat Screen         │
│      (Main Interaction)     │
├─────────────────────────────┤
│       Profile Screen        │
│  (Settings, Memory, Prefs)  │
├─────────────────────────────┤
│        Call Screen          │
│   (Voice/Avatar Interaction)│
└─────────────────────────────┘
```

### Floating Navigation Bar

**Features:**
- Glassmorphic, semi-transparent design
- Floating above bottom of screen
- Smooth animations between tabs
- Active tab highlighted with glow
- Icon + label for clarity

**Styling:**
- Background: `rgba(255, 255, 255, 0.85)`
- Backdrop blur: 10px
- Border: `rgba(232, 213, 242, 0.3)`
- Shadow: Subtle elevation

---

## 🎨 Color Palette

### Primary Gradients
- **Lavender**: `#F5E6FF` → `#E8D5F2`
- **Teal**: `#E0F7F4` → `#B8E6E1`
- **Peach**: `#FFF4E6` → `#FFE8CC`

### Mood-Based Colors
- **Happy**: `#FFF9E6` → `#FFE680` (Warm Yellow)
- **Energetic**: `#FFE6E6` → `#FF9999` (Warm Red)
- **Neutral**: `#E6F0FF` → `#99CCFF` (Cool Blue)
- **Calm**: `#E6F9F5` → `#99E6D9` (Soft Teal)
- **Sad**: `#E6E6FF` → `#9999FF` (Soft Purple)

### Neutral Palette
- White: `#FFFFFF`
- Off-white: `#F8F8FA`
- Light Gray: `#F0F0F5`
- Dark Gray: `#808088`
- Charcoal: `#2A2A35`
- Black: `#1A1A1F`

---

## 📐 Typography System

### Headers
- **H1**: 32px, 700 weight, -0.5 letter spacing
- **H2**: 28px, 700 weight, -0.3 letter spacing
- **H3**: 24px, 600 weight, -0.2 letter spacing
- **H4**: 20px, 600 weight

### Body Text
- **Large**: 16px, 400 weight, 24px line height
- **Medium**: 14px, 400 weight, 20px line height
- **Small**: 12px, 400 weight, 18px line height

### Labels
- **Large**: 14px, 600 weight, 20px line height
- **Medium**: 12px, 600 weight, 16px line height
- **Small**: 11px, 600 weight, 14px line height

---

## 🔲 Spacing System

- **XS**: 4px
- **SM**: 8px
- **MD**: 12px
- **LG**: 16px
- **XL**: 24px
- **XXL**: 32px
- **XXXL**: 48px

---

## 🔘 Border Radius

- **XS**: 4px (subtle)
- **SM**: 8px (small elements)
- **MD**: 12px (cards)
- **LG**: 16px (large cards)
- **XL**: 20px (buttons)
- **XXL**: 24px (modals)
- **Full**: 9999px (circles)

---

## 🎁 Reusable Components

### 1. **ModernButton**
```typescript
<ModernButton
  label="Send"
  variant="primary" | "secondary" | "outline" | "ghost"
  size="sm" | "md" | "lg"
  icon="paperplane.fill"
  iconPosition="left" | "right"
  isLoading={false}
  disabled={false}
  glowing={true}
  onPress={() => {}}
/>
```

**Variants:**
- **Primary**: Filled with primary color, glowing effect
- **Secondary**: Filled with secondary color
- **Outline**: Transparent with border
- **Ghost**: Transparent, no border

### 2. **GradientBackground**
```typescript
<GradientBackground
  gradient="primary" | "secondary" | "warm" | "cool" | "vibrant" | "dark" | "happy" | "energetic" | "neutral" | "calm" | "sad"
  style={{}}
>
  {children}
</GradientBackground>
```

### 3. **ModernCard**
```typescript
<ModernCard
  variant="elevated" | "outlined" | "filled" | "glass"
  padding="sm" | "md" | "lg"
  style={{}}
>
  {children}
</ModernCard>
```

**Variants:**
- **Elevated**: White with shadow
- **Outlined**: White with border
- **Filled**: Colored background
- **Glass**: Semi-transparent with blur

### 4. **ChatBubble**
```typescript
<ChatBubble
  message="Hello!"
  isUser={false}
  timestamp={new Date()}
  mood="happy"
  style={{}}
/>
```

**Features:**
- Curved corners (asymmetric)
- Mood-based coloring for Ally messages
- Glow effect around Ally bubbles
- Timestamp display
- Smooth animations

### 5. **FloatingNavBar**
```typescript
<FloatingNavBar
  items={[
    { name: 'chat', icon: 'bubble.left', label: 'Chat', onPress: () => {} },
    { name: 'profile', icon: 'person', label: 'Profile', onPress: () => {} },
    { name: 'call', icon: 'phone', label: 'Call', onPress: () => {} },
  ]}
  activeIndex={0}
  style={{}}
/>
```

### 6. **ModernHeader**
```typescript
<ModernHeader
  title="Chat"
  subtitle="How are you feeling?"
  leftIcon="chevron.left"
  rightIcon="gear"
  onLeftPress={() => {}}
  onRightPress={() => {}}
  backgroundColor="#FFFFFF"
/>
```

---

## 📱 Screen Redesigns

### Chat Screen
**Layout:**
```
┌─────────────────────────┐
│   Modern Header         │
│  "Hey {name}, how are   │
│   you feeling today?"   │
├─────────────────────────┤
│                         │
│   Chat Messages         │
│   (Smooth Bubbles)      │
│                         │
├─────────────────────────┤
│  Input Field + Send     │
│  (Rounded, Glowing)     │
└─────────────────────────┘
```

**Features:**
- Dynamic greeting header
- Smooth gradient background (mood-based)
- Curved chat bubbles with glow
- Animated typing indicator
- Floating input area
- TTS toggle with glow effect

### Profile Screen
**Layout:**
```
┌─────────────────────────┐
│   Modern Header         │
│      "Profile"          │
├─────────────────────────┤
│   User Info Card        │
│   (Elevated, Rounded)   │
├─────────────────────────┤
│   Settings Sections     │
│   (Cards with Icons)    │
├─────────────────────────┤
│   Memory Log Button     │
│   Avatar Chat Button    │
└─────────────────────────┘
```

**Features:**
- User profile card
- Settings organized in cards
- Quick access buttons
- Smooth transitions
- Glassmorphic sections

### Call Screen
**Layout:**
```
┌─────────────────────────┐
│   Modern Header         │
│      "Avatar Chat"      │
├─────────────────────────┤
│   Mode Tabs             │
│  (Text | Voice | Avatar)│
├─────────────────────────┤
│   Avatar Display        │
│   (Animated, Glowing)   │
├─────────────────────────┤
│   Input + Send          │
│   (Rounded, Glowing)    │
└─────────────────────────┘
```

**Features:**
- Tab navigation between modes
- Animated avatar with mood
- Mood-based background color
- Wave animation when speaking
- Smooth transitions

---

## ✨ Animation & Motion

### Transitions
- **Smooth**: 300ms cubic-bezier(0.4, 0, 0.2, 1)
- **Bounce**: 500ms cubic-bezier(0.68, -0.55, 0.265, 1.55)
- **Spring**: 400ms cubic-bezier(0.34, 1.56, 0.64, 1)

### Animations
- **Fast**: 150ms
- **Normal**: 300ms
- **Slow**: 500ms
- **Slower**: 800ms

### Effects
- **Chat Bubbles**: Fade in with delay
- **Typing Indicator**: Gentle pulse
- **Avatar**: Subtle bounce when typing
- **Nav Bar**: Slides up on scroll
- **Background**: Subtle gradient shift with mood

---

## 🌙 Dark Mode Support

All components automatically adapt to dark mode:
- Background: `#1A1A1F`
- Surface: `#2A2A35`
- Text: `#F8F8FA`
- Borders: `rgba(255, 255, 255, 0.1)`

---

## 📐 Sizing Guidelines

### Touch Targets
- Minimum: 44x44 points
- Buttons: 44-60 points
- Icons: 20-24 points
- Spacing: 16-24 points

### Cards
- Padding: 16-24 points
- Border radius: 12-16 points
- Max width: 85% on mobile

### Modals
- Border radius: 24 points
- Padding: 24 points
- Max height: 80% of screen

---

## 🎯 Implementation Checklist

- ✅ Modern theme system created
- ✅ Reusable components built
- ✅ Navigation redesigned (3 tabs)
- ✅ Floating nav bar implemented
- ✅ Color palette defined
- ✅ Typography system established
- ✅ Spacing system defined
- ✅ Shadow/glow effects created
- ⏳ Chat screen refactored
- ⏳ Profile screen refactored
- ⏳ Call screen refactored
- ⏳ Animations added
- ⏳ Dark mode tested

---

## 📚 File Structure

```
constants/
└── modernTheme.ts (Complete theme system)

components/modern/
├── ModernButton.tsx (Rounded, glowing buttons)
├── GradientBackground.tsx (Mood-based backgrounds)
├── ModernCard.tsx (Elevated, outlined, filled, glass)
├── ChatBubble.tsx (Curved, glowing chat bubbles)
├── FloatingNavBar.tsx (Glassmorphic bottom nav)
└── ModernHeader.tsx (Dynamic headers)
```

---

## 🚀 Usage Example

```typescript
import GradientBackground from '@/components/modern/GradientBackground';
import ModernHeader from '@/components/modern/ModernHeader';
import ChatBubble from '@/components/modern/ChatBubble';
import ModernButton from '@/components/modern/ModernButton';
import FloatingNavBar from '@/components/modern/FloatingNavBar';
import ModernTheme from '@/constants/modernTheme';

export default function ChatScreen() {
  return (
    <GradientBackground gradient="primary">
      <ModernHeader
        title="Chat"
        subtitle="How are you feeling today?"
        rightIcon="gear"
      />
      
      {/* Chat messages */}
      <ChatBubble
        message="Hey! How's your day going?"
        isUser={false}
        mood="happy"
      />
      
      {/* Input */}
      <ModernButton
        label="Send"
        variant="primary"
        glowing={true}
        onPress={() => {}}
      />
      
      {/* Navigation */}
      <FloatingNavBar
        items={[...]}
        activeIndex={0}
      />
    </GradientBackground>
  );
}
```

---

## 🎨 Design Tokens

All design values are centralized in `modernTheme.ts`:
- Colors
- Gradients
- Typography
- Spacing
- Border radius
- Shadows
- Glassmorphism
- Animation timings

---

## 📖 Next Steps

1. **Refactor Chat Screen** with modern components
2. **Refactor Profile Screen** with modern layout
3. **Refactor Call Screen** with modern design
4. **Add animations** using React Native Reanimated
5. **Test dark mode** across all screens
6. **Polish transitions** between tabs
7. **Add gesture animations** for interactions

---

**Status: 🎨 Design System Complete, Components Ready**

**Last Updated**: November 11, 2024
